import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sparkles, ShieldCheck, Truck, HeartHandshake, Star, ArrowRight, Check, Mail } from 'lucide-react';

const navLinks = [
  { label: 'Collection', href: '#showcase' },
  { label: 'Features', href: '#features' },
  { label: 'Benefits', href: '#benefits' },
  { label: 'Pricing', href: '#pricing' },
];

const features = [
  { icon: Sparkles, title: 'Handcrafted Details', desc: 'Every stitch tells a story. Our artisans blend tradition with contemporary vision.' },
  { icon: ShieldCheck, title: 'Quality Assured', desc: 'Premium fabrics and rigorous quality checks ensure lasting luxury.' },
  { icon: Truck, title: 'Global Delivery', desc: 'Express worldwide shipping with premium packaging and white-glove service.' },
  { icon: HeartHandshake, title: 'Personal Styling', desc: 'Dedicated consultants help you find the perfect expression of self.' },
];

const benefits = [
  { stat: '500+', label: 'Luxury Designs' },
  { stat: '42', label: 'Countries Served' },
  { stat: '24h', label: 'Stylist Access' },
];

const testimonials = [
  { name: 'Elena Marchetti', role: 'Fashion Editor', quote: 'Raw Line understands that a dress is not just fabric — it is a statement. Their collection is breathtaking.' },
  { name: 'Amara Njeri', role: 'Creative Director', quote: 'I have never experienced such a seamless blend of luxury and approachability. Every piece feels personal.' },
  { name: 'Sophia Li', role: 'Bride & Client', quote: 'The personal styling session changed how I see fashion. The dress made me feel unstoppable.' },
];

const faq = [
  { q: 'What makes Raw Line different?', a: 'We merge artisan craftsmanship with modern silhouettes, using sustainably sourced luxury fabrics that feel as remarkable as they look.' },
  { q: 'Can I customize a dress?', a: 'Yes. Our bespoke service allows alterations in length, color palette, and embellishment — crafted just for you.' },
  { q: 'How long is delivery?', a: 'Standard orders ship within 3-5 business days. Bespoke pieces require 10-14 days with full tracking and updates.' },
  { q: 'What is your return policy?', a: 'We accept returns within 14 days in original condition with full refund or exchange, no questions asked.' },
];

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-parchment text-ink font-body overflow-x-hidden">
      {/* Navbar */}
      <nav className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? 'glass shadow-[0_8px_30px_rgb(0,0,0,0.06)] py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <a href="#" className="font-display text-2xl font-semibold tracking-tight">Raw Line</a>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-ink/80">
            {navLinks.map(l => <a key={l.href} href={l.href} className="hover:text-ink hover:underline underline-offset-4 decoration-gold/60 decoration-2 transition">{l.label}</a>)}
            <a href="#pricing" className="ml-2 px-5 py-2.5 rounded-full bg-ink text-parchment text-sm font-medium hover:bg-ink/90 transition shadow-xl shadow-ink/20">Shop Collection</a>
          </div>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2" aria-label="Toggle menu">
            {mobileOpen ? <X /> : <Menu />}
          </button>
        </div>
        <AnimatePresence>
          {mobileOpen && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="md:hidden overflow-hidden glass mx-4 rounded-2xl mt-3">
              <div className="flex flex-col gap-4 px-6 py-6 text-base font-medium">
                {navLinks.map(l => <a key={l.href} href={l.href} onClick={() => setMobileOpen(false)} className="hover:text-gold transition">{l.label}</a>)}
                <a href="#pricing" onClick={() => setMobileOpen(false)} className="mt-2 px-5 py-3 rounded-full bg-ink text-parchment text-center">Shop Collection</a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center pt-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="/hero-dress.jpg" alt="Luxury Dress" className="w-full h-full object-cover opacity-30 scale-105" />
          <div className="absolute inset-0 bg-gradient-to-b from-parchment/60 via-parchment/40 to-parchment" />
        </div>
        <div className="relative z-10 max-w-6xl mx-auto px-6 w-full grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, ease: 'easeOut' }}>
            <span className="inline-block px-4 py-1.5 rounded-full text-xs tracking-widest uppercase text-gold border border-gold/30 bg-gold/5 mb-6">New Season 2026</span>
            <h1 className="font-display text-6xl md:text-8xl font-light leading-[0.92] tracking-tight mb-8">
              Where Elegance <br />
              <span className="italic font-normal">Meets Every</span><br />
              <span className="font-semibold">Moment</span>
            </h1>
            <p className="text-muted text-lg md:text-xl leading-relaxed max-w-md mb-10">
              A curated collection of luxury fancy dresses, crafted for women who define their own standard of beauty.
            </p>
            <div className="flex gap-4">
              <a href="#showcase" className="px-8 py-4 rounded-full bg-ink text-parchment font-medium shadow-[0_12px_40px_rgba(10,10,12,0.35)] hover:shadow-[0_16px_50px_rgba(10,10,12,0.5)] transition">Explore Collection</a>
              <a href="#benefits" className="px-8 py-4 rounded-full border border-ink/20 text-ink font-medium hover:bg-ink hover:text-parchment transition">Our Promise</a>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1, delay: 0.15 }} className="hidden md:block relative">
            <div className="rounded-[2.5rem] overflow-hidden shadow-[0_30px_80px_rgba(10,10,12,0.25)] ring-1 ring-ink/5">
              <img src="/hero-dress.jpg" alt="Luxury Dress" className="w-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-ink text-parchment rounded-2xl px-6 py-5 shadow-2xl shadow-ink/20">
              <p className="font-display text-3xl font-semibold">500+</p>
              <p className="text-sm text-parchment/70">Luxury Designs</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-16 bg-ink text-parchment overflow-hidden relative">
        <div className="max-w-6xl mx-auto px-6">
          <p className="text-center text-parchment/50 text-xs tracking-[0.25em] uppercase mb-8">As featured in</p>
          <div className="flex flex-wrap justify-center gap-10 md:gap-20 items-center opacity-60">
            {['Vogue', 'Harper\'s Bazaar', 'Elle', 'The Cut', 'W Magazine'].map(name => (
              <span key={name} className="font-display text-xl md:text-2xl font-light tracking-tight">{name}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-28 max-w-6xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <h2 className="font-display text-4xl md:text-6xl font-light mb-6">Crafted Without Compromise</h2>
          <p className="text-muted text-lg">Every detail is intentional. From the first sketch to final delivery, excellence guides every choice.</p>
        </div>
        <div className="grid md:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: i * 0.1 }} className="group p-8 rounded-3xl bg-cream/40 hover:bg-white hover:shadow-[0_20px_60px_rgba(10,10,12,0.06)] transition-all duration-300 border border-transparent hover:border-gold/20">
              <div className="w-12 h-12 rounded-2xl bg-gold/10 text-gold flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300"><f.icon size={22} /></div>
              <h3 className="font-display text-2xl font-semibold mb-3">{f.title}</h3>
              <p className="text-muted text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Product Showcase */}
      <section id="showcase" className="py-28 max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-gold text-xs tracking-[0.2em] uppercase font-medium">The Collection</span>
            <h2 className="font-display text-5xl md:text-7xl font-light mt-4 mb-8 leading-[0.95]">Dress Like You Mean It</h2>
            <p className="text-muted text-lg leading-relaxed mb-8">
              Each piece in the Raw Line collection is a conversation between silk, light, and silhouette. Designed for women who see fashion as self-expression — not costume.
            </p>
            <ul className="space-y-4 mb-10">
              {['Hand-selected silk and satin blends', 'Tailored fits for every silhouette', 'Custom embellishment options', 'Sustainably sourced luxury fabrics'].map(item => (
                <li key={item} className="flex items-center gap-3 text-ink/80"><Check size={18} className="text-gold shrink-0" /> <span>{item}</span></li>
              ))}
            </ul>
            <a href="#pricing" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-ink text-parchment font-medium hover:bg-ink/85 transition shadow-lg shadow-ink/20">Discover Prices <ArrowRight size={16} /></a>
          </div>
          <div className="relative">
            <img src="/dress-collection.jpg" alt="Collection" className="rounded-[3rem] shadow-[0_30px_80px_rgba(10,10,12,0.15)] object-cover" />
            <div className="absolute top-6 right-6 glass rounded-2xl px-5 py-4 text-center shadow-xl">
              <p className="font-display text-3xl font-semibold">42</p>
              <p className="text-xs text-muted">Countries</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section id="benefits" className="py-28 bg-ink text-parchment">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-display text-5xl md:text-6xl font-light leading-[0.95] mb-8">For Every Version of You</h2>
              <p className="text-parchment/70 text-lg leading-relaxed mb-12">Whether it is a gala, a wedding, or an evening that demands presence — we build dresses that match your energy and elevate it.</p>
              <div className="grid grid-cols-3 gap-6">
                {benefits.map(b => (
                  <div key={b.label} className="text-center">
                    <p className="font-display text-4xl font-light text-gold mb-2">{b.stat}</p>
                    <p className="text-xs text-parchment/50 uppercase tracking-wider">{b.label}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative rounded-[2.5rem] overflow-hidden shadow-[0_40px_80px_rgba(0,0,0,0.3)]">
              <img src="/hero-dress.jpg" alt="Elegant" className="w-full object-cover" />
              <div className="absolute bottom-0 inset-x-0 p-8 bg-gradient-to-t from-ink/80 to-transparent">
                <p className="font-display text-2xl italic text-gold-light">"Every stitch is a promise of beauty."</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-28 max-w-6xl mx-auto px-6">
        <h2 className="font-display text-4xl md:text-6xl font-light text-center mb-16">Words From Our Circle</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div key={t.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: i * 0.15 }} className="p-8 rounded-[2rem] bg-cream/50 border border-ink/5 hover:shadow-xl hover:-translate-y-1 transition duration-300">
              <div className="flex gap-1 mb-6">
                {[1, 2, 3, 4, 5].map(s => <Star key={s} size={14} className="text-gold fill-gold" />)}
              </div>
              <blockquote className="font-display text-xl md:text-2xl font-light leading-relaxed mb-8">"{t.quote}"</blockquote>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-gold/30 to-gold/10 flex items-center justify-center text-gold font-display font-semibold text-sm">{t.name[0]}</div>
                <div>
                  <p className="font-medium text-sm">{t.name}</p>
                  <p className="text-xs text-muted">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-28 max-w-6xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="font-display text-5xl md:text-6xl font-light mb-6">Invest in Presence</h2>
          <p className="text-muted text-lg">Transparent pricing for luxury without compromise. Choose the experience that fits your vision.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {[
            { name: 'Essential', price: '$480', desc: 'Perfect for intimate events. Includes standard tailoring and one fitting.', features: ['One luxury dress', 'Standard tailoring', '14-day return', 'Express shipping'] },
            { name: 'Signature', price: '$890', desc: 'Most popular. Full styling support and bespoke adjustments included.', features: ['Two curated pieces', 'Personal stylist session', 'Custom alterations', 'Premium packaging', 'Priority delivery'] },
            { name: 'Bespoke', price: '$1,850', desc: 'The ultimate experience. A fully custom dress designed with you.', features: ['Custom design', '3 in-person fittings', 'Hand embroidery option', 'Dedicated concierge', 'Lifetime alterations'] },
          ].map((plan, i) => (
            <div key={plan.name} className={`relative p-8 md:p-10 rounded-[2.5rem] border transition duration-300 hover:shadow-2xl hover:-translate-y-2 ${i === 1 ? 'bg-ink text-parchment border-ink shadow-[0_30px_60px_rgba(10,10,12,0.25)]' : 'bg-white border-gold/20 shadow-[0_20px_50px_rgba(10,10,12,0.04)]'}`}>
              {i === 1 && <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] uppercase tracking-wider bg-gold text-ink font-bold">Most Popular</span>}
              <h3 className="font-display text-2xl font-semibold mb-2">{plan.name}</h3>
              <p className={`text-sm mb-6 ${i === 1 ? 'text-parchment/60' : 'text-muted'}`}>{plan.desc}</p>
              <div className="mb-8">
                <span className="font-display text-5xl font-light">{plan.price}</span>
                <span className={`text-sm ml-1 ${i === 1 ? 'text-parchment/40' : 'text-muted'}`}>USD</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map(f => (
                  <li key={f} className={`flex items-center gap-3 text-sm ${i === 1 ? 'text-parchment/80' : 'text-ink/70'}`}>
                    <Check size={16} className={`${i === 1 ? 'text-gold' : 'text-gold'}`} /> {f}
                  </li>
                ))}
              </ul>
              <a href="#" className={`block text-center py-3.5 rounded-full font-medium transition ${i === 1 ? 'bg-parchment text-ink hover:bg-white' : 'bg-ink text-parchment hover:bg-ink/85'}`}>Select Plan</a>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-28 max-w-3xl mx-auto px-6">
        <h2 className="font-display text-4xl md:text-5xl text-center mb-16">Questions, Clarified</h2>
        <div className="space-y-4">
          {faq.map((item, i) => (
            <div key={i} className="bg-white rounded-2xl border border-ink/5 overflow-hidden shadow-[0_8px_30px_rgba(10,10,12,0.03)]">
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full text-left px-6 py-5 flex items-center justify-between font-display text-xl hover:bg-cream/40 transition">
                <span>{item.q}</span>
                <span className={`transition-transform duration-300 ${openFaq === i ? 'rotate-45' : ''}`}>+</span>
              </button>
              <motion.div initial={false} animate={{ height: openFaq === i ? 'auto' : 0, opacity: openFaq === i ? 1 : 0 }} className="overflow-hidden px-6">
                <p className="text-muted text-sm leading-relaxed pb-5">{item.a}</p>
              </motion.div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-28 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="/hero-dress.jpg" className="w-full h-full object-cover opacity-20" alt="" />
          <div className="absolute inset-0 bg-gradient-to-r from-parchment via-parchment/80 to-parchment" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-display text-5xl md:text-7xl font-light mb-8 leading-[0.95]">Start Your Story</h2>
          <p className="text-muted text-xl mb-10 max-w-xl mx-auto">Join thousands of women who choose presence over noise. Your perfect dress is one decision away.</p>
          <a href="#pricing" className="inline-flex items-center gap-2 px-10 py-5 rounded-full bg-ink text-parchment text-lg font-medium shadow-[0_20px_60px_rgba(10,10,12,0.3)] hover:shadow-[0_30px_80px_rgba(10,10,12,0.45)] hover:-translate-y-0.5 transition duration-300">Begin Your Journey <ArrowRight size={20} /></a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-ink text-parchment py-16">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-4 gap-12">
          <div>
            <a href="#" className="font-display text-3xl font-semibold">Raw Line</a>
            <p className="text-parchment/50 text-sm mt-4 leading-relaxed">Luxury fancy dress for every kind of woman. Designed with intention, delivered with care.</p>
          </div>
          <div>
            <h4 className="font-display text-xl mb-4">Explore</h4>
            <ul className="space-y-2 text-sm text-parchment/50">
              {['Collection', 'Bespoke Service', 'Styling', 'Gift Cards'].map(link => (
                <li key={link}><a href="#" className="hover:text-parchment transition">{link}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-display text-xl mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-parchment/50">
              {['Shipping', 'Returns', 'Size Guide', 'Contact'].map(link => (
                <li key={link}><a href="#" className="hover:text-parchment transition">{link}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-display text-xl mb-4">Stay Updated</h4>
            <form className="flex gap-2" onSubmit={e => e.preventDefault()}>
              <input type="email" placeholder="Your email" className="flex-1 px-4 py-2.5 rounded-full bg-parchment/10 border border-parchment/10 text-sm placeholder:text-parchment/30 focus:outline-none focus:border-gold transition" />
              <button type="submit" className="p-2.5 rounded-full bg-gold text-ink hover:bg-gold-light transition"><Mail size={18} /></button>
            </form>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-6 mt-12 pt-8 border-t border-parchment/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-parchment/30">
          <p>© 2026 Raw Line. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-parchment transition">Privacy</a>
            <a href="#" className="hover:text-parchment transition">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
