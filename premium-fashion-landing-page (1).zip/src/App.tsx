import Navbar from './components/Navbar';
import Hero from './components/Hero';
import SocialProof from './components/SocialProof';
import Features from './components/Features';
import ProductShowcase from './components/ProductShowcase';
import Categories from './components/Categories';
import Benefits from './components/Benefits';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import DownloadCatalogs from './components/DownloadCatalogs';
import FAQ from './components/FAQ';
import CTA from './components/CTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-surface text-gray-200">
      <Navbar />
      <main>
        <Hero />
        <SocialProof />
        <Features />
        <ProductShowcase />
        <Categories />
        <Benefits />
        <Testimonials />
        <Pricing />
        <DownloadCatalogs />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
