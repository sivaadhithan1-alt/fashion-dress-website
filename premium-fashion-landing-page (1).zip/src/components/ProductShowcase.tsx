import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { ArrowRight, Heart, Star, ShoppingBag } from 'lucide-react';
import { useState } from 'react';

const categories = ['All', 'Women', 'Men', 'Kids', 'Couples', 'Groups'];

const products = [
  {
    name: 'Venetian Masquerade',
    category: 'Women',
    price: 89.99,
    originalPrice: 129.99,
    image: 'https://images.pexels.com/photos/9391416/pexels-photo-9391416.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.9,
    reviews: 342,
    badge: 'Bestseller',
    badgeColor: 'bg-brand-500',
  },
  {
    name: 'Renaissance Royalty',
    category: 'Women',
    price: 119.99,
    originalPrice: 169.99,
    image: 'https://images.pexels.com/photos/6731813/pexels-photo-6731813.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.8,
    reviews: 218,
    badge: 'New',
    badgeColor: 'bg-accent-500',
  },
  {
    name: 'Fantasy Pirate',
    category: 'Women',
    price: 79.99,
    originalPrice: 109.99,
    image: 'https://images.pexels.com/photos/5233511/pexels-photo-5233511.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.7,
    reviews: 156,
    badge: null,
    badgeColor: '',
  },
  {
    name: 'Medieval Princess',
    category: 'Women',
    price: 99.99,
    originalPrice: 149.99,
    image: 'https://images.pexels.com/photos/33937680/pexels-photo-33937680.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.9,
    reviews: 423,
    badge: 'Top Rated',
    badgeColor: 'bg-gold-500',
  },
  {
    name: 'Carnival Spirit',
    category: 'Couples',
    price: 149.99,
    originalPrice: 219.99,
    image: 'https://images.pexels.com/photos/31089869/pexels-photo-31089869.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.8,
    reviews: 187,
    badge: 'Trending',
    badgeColor: 'bg-emerald-500',
  },
  {
    name: 'Renaissance Performer',
    category: 'Men',
    price: 94.99,
    originalPrice: 139.99,
    image: 'https://images.pexels.com/photos/29155437/pexels-photo-29155437.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.6,
    reviews: 98,
    badge: null,
    badgeColor: '',
  },
  {
    name: 'Skeleton Duo',
    category: 'Kids',
    price: 49.99,
    originalPrice: 69.99,
    image: 'https://images.pexels.com/photos/9740507/pexels-photo-9740507.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.9,
    reviews: 567,
    badge: 'Kids Fav',
    badgeColor: 'bg-sky-500',
  },
  {
    name: 'Gothic Elegance',
    category: 'Women',
    price: 109.99,
    originalPrice: 159.99,
    image: 'https://images.pexels.com/photos/33937678/pexels-photo-33937678.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=450',
    rating: 4.7,
    reviews: 213,
    badge: null,
    badgeColor: '',
  },
];

export default function ProductShowcase() {
  const { ref, isVisible } = useScrollReveal();
  const [activeCategory, setActiveCategory] = useState('All');
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null);

  const filtered = activeCategory === 'All' ? products : products.filter(p => p.category === activeCategory);

  return (
    <section ref={ref} id="collections" className="py-24 lg:py-32 relative">
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-brand-500/5 rounded-full blur-[150px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            Our Collection
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Costumes That{' '}
            <span className="gradient-text">Captivate</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400"
          >
            Hand-picked designs for every personality. Find the costume that speaks to your soul.
          </motion.p>
        </div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="flex flex-wrap justify-center gap-2 mb-12"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-brand-500 to-accent-500 text-white shadow-lg shadow-brand-500/20'
                  : 'glass-light text-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        {/* Product Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filtered.map((product, i) => (
            <motion.div
              key={product.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.08 + 0.3 }}
              onMouseEnter={() => setHoveredProduct(i)}
              onMouseLeave={() => setHoveredProduct(null)}
              className="group relative glass-light rounded-2xl overflow-hidden card-hover"
            >
              {/* Image */}
              <div className="relative h-72 sm:h-80 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                
                {/* Badge */}
                {product.badge && (
                  <span className={`absolute top-4 left-4 ${product.badgeColor} text-white text-xs font-bold px-3 py-1 rounded-full`}>
                    {product.badge}
                  </span>
                )}

                {/* Action buttons */}
                <div className={`absolute top-4 right-4 flex flex-col gap-2 transition-all duration-300 ${
                  hoveredProduct === i ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                }`}>
                  <button className="w-9 h-9 rounded-full glass flex items-center justify-center text-white hover:bg-brand-500 transition-colors" aria-label="Add to wishlist">
                    <Heart className="w-4 h-4" />
                  </button>
                  <button className="w-9 h-9 rounded-full glass flex items-center justify-center text-white hover:bg-brand-500 transition-colors" aria-label="Add to cart">
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>

                {/* Sale tag */}
                <div className="absolute bottom-4 left-4">
                  <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md">
                    {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                  </span>
                </div>
              </div>

              {/* Details */}
              <div className="p-5">
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-3.5 h-3.5 fill-gold-400 text-gold-400" />
                  <span className="text-sm text-gray-300 font-medium">{product.rating}</span>
                  <span className="text-xs text-gray-500">({product.reviews})</span>
                </div>
                <h3 className="font-semibold text-white group-hover:text-brand-300 transition-colors">
                  {product.name}
                </h3>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-lg font-bold text-white">${product.price}</span>
                  <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-12 text-center"
        >
          <a
            href="#"
            className="inline-flex items-center gap-2 text-brand-400 hover:text-brand-300 font-semibold transition-colors group"
          >
            View All 1,500+ Costumes
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
