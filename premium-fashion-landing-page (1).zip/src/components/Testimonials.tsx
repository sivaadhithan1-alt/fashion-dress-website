import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Mitchell',
    role: 'Halloween Party Host',
    avatar: 'https://images.pexels.com/photos/590479/pexels-photo-590479.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'The Venetian Masquerade set was absolutely stunning. The quality of the fabrics and the attention to detail is unmatched. I felt like true royalty at our company gala. Everyone wanted to know where I got it!',
    highlight: 'felt like true royalty',
  },
  {
    name: 'Marcus Johnson',
    role: 'Cosplay Enthusiast',
    avatar: 'https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'As someone who does cosplay professionally, I\'m very picky about costumes. DressUp exceeded all my expectations. The Renaissance collection is museum-quality. These are investment pieces, not cheap throwaway costumes.',
    highlight: 'museum-quality',
  },
  {
    name: 'Elena Rodriguez',
    role: 'Event Planner',
    avatar: 'https://images.pexels.com/photos/6497114/pexels-photo-6497114.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'I ordered costumes for a corporate themed event — 40 people, all different sizes. DressUp\'s team was incredible. Every single costume fit perfectly. The group discount made it affordable and the express delivery saved us.',
    highlight: 'Every single costume fit perfectly',
  },
  {
    name: 'David Chen',
    role: 'Father of Three',
    avatar: 'https://images.pexels.com/photos/7562139/pexels-photo-7562139.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'My kids absolutely LOVED their skeleton costumes. The glow-in-the-dark details were a huge hit. Most importantly, the materials are soft and comfortable — they wore them all day without any complaints. Will definitely buy again.',
    highlight: 'wore them all day without any complaints',
  },
  {
    name: 'Amara Okafor',
    role: 'Theater Director',
    avatar: 'https://images.pexels.com/photos/37272329/pexels-photo-37272329.png?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'We use DressUp costumes for our community theater productions. The durability is exceptional — they withstand dozens of performances and still look brand new. The custom tailoring option is a game-changer for theatrical use.',
    highlight: 'still look brand new',
  },
  {
    name: 'James Whitfield',
    role: 'Wedding Planner',
    avatar: 'https://images.pexels.com/photos/18891841/pexels-photo-18891841.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=100&w=100',
    rating: 5,
    text: 'Themed weddings are all the rage, and DressUp is my go-to recommendation for clients. The quality bridges the gap between costume and couture. The 30-day return policy gives my clients total peace of mind.',
    highlight: 'bridges the gap between costume and couture',
  },
];

export default function Testimonials() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} id="testimonials" className="py-24 lg:py-32 relative">
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-accent-500/5 rounded-full blur-[150px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            Customer Stories
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Loved by{' '}
            <span className="gradient-text">Everyone</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400"
          >
            Don't just take our word for it. Here's what our community has to say.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 + 0.2 }}
              className="group glass-light rounded-2xl p-6 lg:p-7 card-hover relative"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-brand-500/10 group-hover:text-brand-500/20 transition-colors" />
              
              <div className="flex items-center gap-1 mb-4">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-gold-400 text-gold-400" />
                ))}
              </div>

              <p className="text-gray-300 leading-relaxed text-sm mb-6">
                "{t.text}"
              </p>

              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-brand-500/30"
                  loading="lazy"
                />
                <div>
                  <p className="font-semibold text-white text-sm">{t.name}</p>
                  <p className="text-xs text-gray-500">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
