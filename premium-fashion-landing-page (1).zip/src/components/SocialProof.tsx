import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';

const logos = [
  { name: 'Disney', text: 'Disney' },
  { name: 'Netflix', text: 'Netflix' },
  { name: 'Marvel', text: 'Marvel' },
  { name: 'Vogue', text: 'VOGUE' },
  { name: 'HBO', text: 'HBO' },
  { name: 'Warner', text: 'Warner Bros.' },
  { name: 'Cosmo', text: 'COSMO' },
  { name: 'Elle', text: 'ELLE' },
];

export default function SocialProof() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} className="py-16 lg:py-20 relative border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.p
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center text-sm font-medium text-gray-500 uppercase tracking-widest mb-10"
        >
          Trusted by leading entertainment & fashion brands
        </motion.p>
        <div className="flex flex-wrap justify-center items-center gap-x-10 gap-y-6 sm:gap-x-16">
          {logos.map((logo, i) => (
            <motion.div
              key={logo.name}
              initial={{ opacity: 0, y: 10 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              className="text-gray-600 hover:text-gray-300 transition-colors duration-300 cursor-default"
            >
              <span className="text-lg sm:text-xl font-bold tracking-wider" style={{ fontFamily: "'Playfair Display', serif" }}>
                {logo.text}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
