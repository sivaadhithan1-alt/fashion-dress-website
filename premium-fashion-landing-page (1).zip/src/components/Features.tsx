import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Palette, Ruler, Shield, Truck, RefreshCw, Headphones } from 'lucide-react';

const features = [
  {
    icon: Palette,
    title: 'Designer Quality',
    description: 'Each costume is crafted by professional designers using premium fabrics and meticulous attention to detail.',
    gradient: 'from-pink-500 to-rose-500',
  },
  {
    icon: Ruler,
    title: 'Perfect Fit Guarantee',
    description: 'Sizes from toddler to 5XL. Our detailed size guides and custom tailoring ensure the perfect fit for everyone.',
    gradient: 'from-violet-500 to-purple-500',
  },
  {
    icon: Shield,
    title: 'Safety Certified',
    description: 'All materials are non-toxic, hypoallergenic, and meet international safety standards. Safe for all ages.',
    gradient: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Truck,
    title: 'Express Delivery',
    description: 'Free standard shipping worldwide. Need it fast? Next-day and same-day delivery available in select cities.',
    gradient: 'from-amber-500 to-orange-500',
  },
  {
    icon: RefreshCw,
    title: '30-Day Returns',
    description: 'Not the right fit? No worries. Free returns within 30 days, no questions asked. We make it easy.',
    gradient: 'from-emerald-500 to-green-500',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our costume experts are available around the clock to help you find the perfect look for any occasion.',
    gradient: 'from-brand-500 to-accent-500',
  },
];

export default function Features() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} id="features" className="py-24 lg:py-32 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-accent-500/5 rounded-full blur-[150px]" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            Why Choose DressUp
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Crafted for{' '}
            <span className="gradient-text">Excellence</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400 leading-relaxed"
          >
            We believe everyone deserves to feel extraordinary. Here's what makes our costumes stand apart.
          </motion.p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 + 0.2 }}
              className="group relative glass-light rounded-2xl p-7 lg:p-8 card-hover cursor-default"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed text-sm">{feature.description}</p>
              
              {/* Hover glow */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-[0.03] transition-opacity duration-500`} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
