import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: 'What sizes do you offer?',
    answer: 'We offer an inclusive range from toddler sizes through adult 5XL. Our Standard and Premium tiers cover XS to 3XL and XXS to 5XL respectively. Our Couture tier offers fully custom measurements for the perfect fit. Each product page includes a detailed size chart with measurements in both inches and centimeters.',
  },
  {
    question: 'How long does shipping take?',
    answer: 'Standard shipping takes 5-7 business days (free on orders over $75). Express shipping delivers in 2-3 business days. Premium members get free express shipping on all orders. Same-day delivery is available in select major cities for Couture tier customers. We ship to over 120 countries worldwide.',
  },
  {
    question: 'What is your return policy?',
    answer: 'Standard tier customers enjoy 14-day returns, while Premium and Couture customers get a full 30-day return window. Returns are completely free — we provide a prepaid return label. Items must be unworn and in original condition with tags attached. Custom/tailored items can be altered once for free if the fit isn\'t right.',
  },
  {
    question: 'Are your costumes suitable for children?',
    answer: 'Absolutely! We have a dedicated Kids collection with 280+ designs for ages 2-16. All children\'s costumes use non-toxic, hypoallergenic materials and meet international safety standards (CPSIA, EN71). Flame-retardant treatments are applied to all children\'s costumes. No small detachable parts on costumes for children under 5.',
  },
  {
    question: 'Can I get a custom or modified costume?',
    answer: 'Yes! Our Couture tier specializes in custom costumes. You can modify any existing design or create something entirely new. The process includes a consultation, design mockup, fitting, and revisions. Turnaround is typically 2-3 weeks. For large group orders (10+), we offer custom modifications on Premium tier as well.',
  },
  {
    question: 'Do you offer group or bulk discounts?',
    answer: 'We offer tiered group pricing: 10-24 costumes receive 10% off, 25-49 costumes receive 15% off, and 50+ costumes receive 20% off. We work regularly with theater groups, schools, corporate events, and wedding parties. Contact our team for a custom group quote.',
  },
  {
    question: 'What materials do you use?',
    answer: 'Our Standard tier uses quality polyester blends. Premium costumes feature high-grade satin, velvet, organza, and premium stretch fabrics. Couture uses luxury materials including silk, real leather accents, and hand-beaded embellishments. All materials are ethically sourced and many options are sustainable.',
  },
  {
    question: 'How do I care for my costume?',
    answer: 'Each costume comes with specific care instructions. Most Standard costumes are machine washable on gentle cycle. Premium and Couture pieces typically require hand washing or dry cleaning. We include a garment storage bag with Premium and Couture orders. Proper care ensures your costume remains stunning for years.',
  },
];

function FAQItem({ faq, isOpen, onToggle, index }: { faq: typeof faqs[0]; isOpen: boolean; onToggle: () => void; index: number }) {
  const { ref, isVisible } = useScrollReveal(0.05);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className={`glass-light rounded-2xl overflow-hidden transition-all duration-300 ${
        isOpen ? 'ring-1 ring-brand-500/30' : ''
      }`}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-6 text-left group"
        aria-expanded={isOpen}
      >
        <span className={`text-base font-semibold pr-4 transition-colors ${isOpen ? 'text-white' : 'text-gray-300 group-hover:text-white'}`}>
          {faq.question}
        </span>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
          isOpen ? 'bg-brand-500/20 rotate-0' : 'bg-white/5 group-hover:bg-white/10'
        }`}>
          {isOpen ? (
            <Minus className="w-4 h-4 text-brand-400" />
          ) : (
            <Plus className="w-4 h-4 text-gray-400" />
          )}
        </div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
          >
            <div className="px-6 pb-6 text-gray-400 leading-relaxed text-sm border-t border-white/5 pt-4">
              {faq.answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function FAQ() {
  const { ref, isVisible } = useScrollReveal();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section ref={ref} id="faq" className="py-24 lg:py-32 relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            FAQ
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Got{' '}
            <span className="gradient-text">Questions?</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400"
          >
            Everything you need to know about DressUp costumes.
          </motion.p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              faq={faq}
              index={i}
              isOpen={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <p className="text-gray-500 text-sm">
            Still have questions?{' '}
            <a href="#" className="text-brand-400 hover:text-brand-300 font-medium transition-colors">
              Chat with our team
            </a>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
