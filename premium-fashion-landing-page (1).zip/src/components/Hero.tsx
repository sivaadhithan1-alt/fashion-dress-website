import { motion } from 'framer-motion';
import { ArrowRight, Star, Users, Award, Play } from 'lucide-react';

const HERO_IMG = 'https://images.pexels.com/photos/9391417/pexels-photo-9391417.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200';
const HERO_IMG_2 = 'https://images.pexels.com/photos/30513428/pexels-photo-30513428.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200';

const stats = [
  { icon: Users, value: '250K+', label: 'Happy Customers' },
  { icon: Star, value: '4.9/5', label: 'Average Rating' },
  { icon: Award, value: '1,500+', label: 'Unique Costumes' },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 lg:pt-0 overflow-hidden hero-gradient noise-bg">
      {/* Ambient orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-brand-500/10 rounded-full blur-[128px] animate-pulse-glow" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent-500/10 rounded-full blur-[128px] animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-600/5 rounded-full blur-[200px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light text-sm font-medium text-brand-300 mb-6"
            >
              <span className="w-2 h-2 rounded-full bg-brand-400 animate-pulse" />
              New 2025 Collection Just Dropped
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-[1.08] tracking-tight text-balance"
            >
              <span className="text-white">Become </span>
              <span className="gradient-text">Anyone</span>
              <br />
              <span className="text-white">You Imagine</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="mt-6 text-lg sm:text-xl text-gray-400 max-w-xl mx-auto lg:mx-0 leading-relaxed"
            >
              Premium fancy dress costumes for every age, every occasion, and every imagination. 
              From enchanting princesses to fearless superheroes — unleash your alter ego.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <a
                href="#collections"
                className="btn-primary px-8 py-4 rounded-2xl text-white font-semibold text-base flex items-center justify-center gap-2 group relative z-10"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Explore Collection
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </a>
              <button className="btn-secondary px-8 py-4 rounded-2xl text-white font-semibold text-base flex items-center justify-center gap-2">
                <Play className="w-4 h-4" />
                Watch Lookbook
              </button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.45 }}
              className="mt-12 grid grid-cols-3 gap-4 sm:gap-8"
            >
              {stats.map((stat, i) => (
                <div key={i} className="text-center lg:text-left">
                  <div className="flex items-center gap-2 justify-center lg:justify-start mb-1">
                    <stat.icon className="w-4 h-4 text-brand-400" />
                    <span className="text-xl sm:text-2xl font-bold text-white">{stat.value}</span>
                  </div>
                  <span className="text-xs sm:text-sm text-gray-500">{stat.label}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right - Hero Images */}
          <div className="relative hidden lg:block">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative z-10"
            >
              {/* Main image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-black/40 border border-white/10">
                <img
                  src={HERO_IMG}
                  alt="Stunning masquerade costume"
                  className="w-full h-[520px] object-cover"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                
                {/* Floating card */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8, duration: 0.5 }}
                  className="absolute bottom-6 left-6 right-6 glass rounded-2xl p-4 flex items-center gap-4"
                >
                  <div className="flex -space-x-2">
                    {[
                      'https://images.pexels.com/photos/7562139/pexels-photo-7562139.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=60&w=60',
                      'https://images.pexels.com/photos/590479/pexels-photo-590479.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=60&w=60',
                      'https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=60&w=60',
                    ].map((src, i) => (
                      <img
                        key={i}
                        src={src}
                        alt=""
                        className="w-9 h-9 rounded-full border-2 border-surface object-cover"
                      />
                    ))}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 mb-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-gold-400 text-gold-400" />
                      ))}
                    </div>
                    <p className="text-xs text-gray-300 truncate">Loved by 250K+ costume enthusiasts</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>

            {/* Floating secondary image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="absolute -bottom-8 -left-12 w-48 h-64 rounded-2xl overflow-hidden shadow-2xl shadow-black/40 border border-white/10 z-20 animate-float-slow"
            >
              <img
                src={HERO_IMG_2}
                alt="Carnival costume"
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </motion.div>

            {/* Decorative elements */}
            <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full border border-brand-500/20 animate-spin-slow" />
            <div className="absolute top-1/2 -right-4 w-3 h-3 rounded-full bg-accent-400 animate-pulse" />
            <div className="absolute -bottom-4 right-1/3 w-2 h-2 rounded-full bg-brand-400 animate-pulse" style={{ animationDelay: '1s' }} />
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-surface to-transparent" />
    </section>
  );
}
