import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import {
  Download,
  FileArchive,
  Sparkles,
  Crown,
  Check,
  Loader2,
  Star,
  Palette,
  Users,
  Image,
  BookOpen,
  Shirt,
  Layers,
  ArrowRight,
  CheckCircle,
} from 'lucide-react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

/* ─────────────── CATALOG DATA ─────────────── */

const catalogAData = {
  name: 'DressUp Essentials Catalog',
  fileName: 'DressUp_Essentials_Catalog.zip',
  files: [
    {
      name: 'README.txt',
      content: `╔══════════════════════════════════════════════════════╗
║           DRESSUP — ESSENTIALS CATALOG 2025          ║
╚══════════════════════════════════════════════════════╝

Welcome to the DressUp Essentials Catalog!

This catalog contains everything you need to explore our 
Standard & Premium costume collections for all occasions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📁 WHAT'S INSIDE:
──────────────────
• Product Catalog (CSV)   — Full lineup of 500+ costumes
• Size Guide (TXT)        — Comprehensive sizing info
• Care Instructions (TXT) — How to maintain your costumes
• Order Form (TXT)        — Quick order template
• Style Guide (TXT)       — Tips for choosing the perfect look

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌐 SHOP ONLINE: www.dressup.com
📧 EMAIL: hello@dressup.com
📞 PHONE: 1-800-555-0199

Use code FIRST20 for 20% off your first order!

© 2025 DressUp. All rights reserved.
`,
    },
    {
      name: 'Product_Catalog.csv',
      content: `SKU,Name,Category,Gender,Size Range,Price (USD),Original Price (USD),Rating,Reviews,In Stock,Material,Theme
DU-W-001,Venetian Masquerade Gown,Masquerade,Women,XS-3XL,89.99,129.99,4.9,342,Yes,Satin & Lace,Masquerade
DU-W-002,Renaissance Royalty Dress,Renaissance,Women,XS-3XL,119.99,169.99,4.8,218,Yes,Velvet & Organza,Renaissance
DU-W-003,Fantasy Pirate Captain,Fantasy,Women,XS-3XL,79.99,109.99,4.7,156,Yes,Cotton & Polyester,Pirate
DU-W-004,Medieval Princess Gown,Medieval,Women,XS-3XL,99.99,149.99,4.9,423,Yes,Satin & Chiffon,Medieval
DU-W-005,Gothic Elegance Ensemble,Gothic,Women,XS-3XL,109.99,159.99,4.7,213,Yes,Velvet & Mesh,Gothic
DU-W-006,Fairy Tale Queen,Fantasy,Women,XS-3XL,94.99,139.99,4.8,189,Yes,Tulle & Satin,Fantasy
DU-W-007,Enchanted Sorceress,Fantasy,Women,XS-3XL,84.99,124.99,4.6,145,Yes,Chiffon & Sequin,Fantasy
DU-W-008,Vintage Flapper Dress,1920s,Women,XS-3XL,74.99,99.99,4.8,267,Yes,Sequin & Fringe,Vintage
DU-M-001,Renaissance Festival Performer,Renaissance,Men,S-3XL,94.99,139.99,4.6,98,Yes,Cotton & Leather,Renaissance
DU-M-002,Viking Warrior Set,Medieval,Men,S-3XL,109.99,159.99,4.8,176,Yes,Faux Leather & Fur,Medieval
DU-M-003,Classic Dracula Cape Set,Gothic,Men,S-3XL,69.99,99.99,4.7,234,Yes,Satin & Polyester,Gothic
DU-M-004,Pirate King Ensemble,Fantasy,Men,S-3XL,89.99,129.99,4.6,112,Yes,Cotton & Faux Leather,Pirate
DU-M-005,Medieval Knight Armor,Medieval,Men,S-3XL,129.99,189.99,4.9,301,Yes,EVA Foam & Fabric,Medieval
DU-M-006,Wild West Sheriff,Western,Men,S-3XL,79.99,109.99,4.5,87,Yes,Denim & Suede,Western
DU-K-001,Skeleton Glow Suit,Halloween,Kids,2T-14Y,49.99,69.99,4.9,567,Yes,Cotton & Glow Fabric,Halloween
DU-K-002,Princess Aurora Dress,Fairy Tale,Kids,2T-14Y,44.99,64.99,4.9,489,Yes,Satin & Tulle,Fairy Tale
DU-K-003,Superhero Cape & Mask Set,Superhero,Kids,2T-14Y,34.99,49.99,4.8,623,Yes,Polyester & Foam,Superhero
DU-K-004,Little Wizard Robe,Fantasy,Kids,2T-14Y,39.99,59.99,4.7,345,Yes,Polyester & Satin,Fantasy
DU-K-005,Dinosaur Full Body Suit,Animal,Kids,2T-14Y,54.99,79.99,4.9,412,Yes,Fleece & Foam,Animal
DU-C-001,Venetian Carnival Duo,Masquerade,Couples,XS-3XL,149.99,219.99,4.8,187,Yes,Satin & Lace,Masquerade
DU-C-002,Romeo & Juliet Set,Renaissance,Couples,XS-3XL,179.99,259.99,4.9,156,Yes,Velvet & Satin,Renaissance
DU-C-003,Pirate Captain & First Mate,Fantasy,Couples,XS-3XL,139.99,199.99,4.7,132,Yes,Cotton & Faux Leather,Pirate
DU-G-001,Wizard School Group (5pc),Fantasy,Groups,XS-3XL,199.99,299.99,4.8,89,Yes,Polyester & Satin,Fantasy
DU-G-002,Medieval Court Set (6pc),Medieval,Groups,XS-3XL,349.99,499.99,4.9,67,Yes,Velvet & Satin,Medieval
DU-A-001,Masquerade Mask Collection,Accessories,Unisex,One Size,24.99,39.99,4.7,892,Yes,Resin & Feather,Masquerade
DU-A-002,Crown & Tiara Set,Accessories,Unisex,One Size,19.99,29.99,4.6,456,Yes,Metal & Crystal,Royal
DU-A-003,Sword & Shield Prop Set,Accessories,Unisex,One Size,34.99,49.99,4.8,334,Yes,EVA Foam,Medieval`,
    },
    {
      name: 'Size_Guide.txt',
      content: `╔══════════════════════════════════════════════════════╗
║              DRESSUP — SIZE GUIDE                    ║
╚══════════════════════════════════════════════════════╝

━━━━━ WOMEN'S SIZES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

 Size  | Bust (in) | Waist (in) | Hips (in) | US Size
─────────────────────────────────────────────────────
  XS   |  31-33    |   24-26    |  34-36    |   0-2
  S    |  33-35    |   26-28    |  36-38    |   4-6
  M    |  35-37    |   28-30    |  38-40    |   8-10
  L    |  37-40    |   30-33    |  40-43    |  12-14
  XL   |  40-43    |   33-36    |  43-46    |  16-18
  2XL  |  43-46    |   36-39    |  46-49    |  20-22
  3XL  |  46-49    |   39-42    |  49-52    |  24-26

━━━━━ MEN'S SIZES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

 Size  | Chest (in) | Waist (in) | Hips (in)
─────────────────────────────────────────────
  S    |  34-36     |   28-30    |  34-36
  M    |  38-40     |   32-34    |  38-40
  L    |  42-44     |   36-38    |  42-44
  XL   |  46-48     |   40-42    |  46-48
  2XL  |  50-52     |   44-46    |  50-52
  3XL  |  54-56     |   48-50    |  54-56

━━━━━ KIDS' SIZES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

 Size  | Age     | Height (in) | Chest (in)
─────────────────────────────────────────────
  2T   | 2 yrs   |   33-35     |   21
  3T   | 3 yrs   |   36-38     |   22
  4T   | 4 yrs   |   39-41     |   23
  5-6  | 5-6 yrs |   42-46     |   24-25
  7-8  | 7-8 yrs |   47-51     |   26-27
 10-12 | 9-12 yrs|   52-58     |   28-30
 14Y   | 13-14   |   59-63     |   31-33

━━━━━ HOW TO MEASURE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔸 BUST/CHEST: Measure around the fullest part
🔸 WAIST: Measure at the narrowest point
🔸 HIPS: Measure around the fullest part
🔸 HEIGHT: Stand straight, measure head to toe

💡 TIP: If between sizes, we recommend sizing up.
   Our Premium & Couture tiers offer custom tailoring.

Need help? Contact us: hello@dressup.com
`,
    },
    {
      name: 'Care_Instructions.txt',
      content: `╔══════════════════════════════════════════════════════╗
║          DRESSUP — COSTUME CARE GUIDE                ║
╚══════════════════════════════════════════════════════╝

Keep your DressUp costumes looking stunning for years
with these care tips.

━━━━━ GENERAL CARE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Always check the specific care label on your costume
✅ Store in the included garment bag when not in use
✅ Hang or fold neatly — avoid cramming in drawers
✅ Keep away from direct sunlight to prevent fading
✅ Address stains promptly with gentle spot cleaning

━━━━━ BY TIER ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏷️ STANDARD COSTUMES
   • Machine washable on gentle/delicate cycle
   • Cold water only (30°C / 86°F max)
   • Mild detergent, no bleach
   • Lay flat or hang to dry
   • Low heat iron if needed (inside out)

⭐ PREMIUM COSTUMES
   • Hand wash recommended for best results
   • Cold water with gentle detergent
   • Do not wring — gently press water out
   • Hang to dry on padded hanger
   • Steam to remove wrinkles (no direct iron)
   • Dry cleaning safe

👑 COUTURE COSTUMES
   • Professional dry cleaning recommended
   • Hand wash only if necessary
   • Store in provided preservation bag
   • Use tissue paper between folds
   • Professional steam pressing recommended

━━━━━ SPECIAL MATERIALS ━━━━━━━━━━━━━━━━━━━━━━━━━━━

🪶 FEATHERS: Spot clean only, steam gently
💎 SEQUINS: Hand wash inside out, no wringing
🧵 EMBROIDERY: Dry clean or very gentle hand wash
🎭 MASKS: Wipe with damp cloth, air dry
⚔️ PROPS: Wipe clean, store separately

Questions? Email care@dressup.com
`,
    },
    {
      name: 'Quick_Order_Form.txt',
      content: `╔══════════════════════════════════════════════════════╗
║          DRESSUP — QUICK ORDER FORM                  ║
╚══════════════════════════════════════════════════════╝

Fill out this form and email to: orders@dressup.com
Or call: 1-800-555-0199

━━━━━ CUSTOMER INFORMATION ━━━━━━━━━━━━━━━━━━━━━━━━

Full Name:      _________________________________
Email:          _________________________________
Phone:          _________________________________
Shipping Addr:  _________________________________
                _________________________________
City:           _________________________________
State/Province: _________________________________
Zip/Postal:     _________________________________
Country:        _________________________________

━━━━━ ORDER DETAILS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

 #  | SKU        | Product Name          | Size | Qty | Price
─────────────────────────────────────────────────────────────
 1  | _________  | _____________________ | ____ | ___ | _____
 2  | _________  | _____________________ | ____ | ___ | _____
 3  | _________  | _____________________ | ____ | ___ | _____
 4  | _________  | _____________________ | ____ | ___ | _____
 5  | _________  | _____________________ | ____ | ___ | _____

━━━━━ PROMO & SHIPPING ━━━━━━━━━━━━━━━━━━━━━━━━━━━

Promo Code:  _________________  (Try FIRST20!)

Shipping:    [ ] Standard (Free over $75)
             [ ] Express ($12.99)
             [ ] Same-Day ($24.99, select cities)

━━━━━ PAYMENT ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Payment:     [ ] Credit Card (processed securely)
             [ ] PayPal
             [ ] Apple Pay / Google Pay
             [ ] Afterpay (Buy now, pay later)

Notes: _____________________________________________
       _____________________________________________

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Prefer online? Visit www.dressup.com for instant checkout!
`,
    },
    {
      name: 'Style_Guide.txt',
      content: `╔══════════════════════════════════════════════════════╗
║          DRESSUP — STYLE GUIDE & TIPS                ║
╚══════════════════════════════════════════════════════╝

Your go-to guide for choosing and styling the perfect
fancy dress costume.

━━━━━ CHOOSING BY OCCASION ━━━━━━━━━━━━━━━━━━━━━━━━

🎃 HALLOWEEN
   Best Picks: Gothic, Skeleton, Zombie, Witch
   Tip: Add glow accessories for night visibility

🎭 MASQUERADE / GALA
   Best Picks: Venetian, Renaissance, Baroque
   Tip: Match mask to gown for a cohesive look

🎉 THEMED PARTY
   Best Picks: Decade themes (70s, 80s, 90s)
   Tip: Coordinate with friends for group impact

🎪 COSPLAY / CONVENTIONS
   Best Picks: Fantasy, Superhero, Anime
   Tip: Layer pieces to build comfort & detail

🎄 HOLIDAY EVENTS
   Best Picks: Santa, Elf, Nutcracker, Winter Fairy
   Tip: Choose comfortable fabrics for long wear

💒 THEMED WEDDING
   Best Picks: Renaissance, Victorian, Fairy Tale
   Tip: Our Couture tier for wedding-quality custom fit

━━━━━ COLOR PSYCHOLOGY ━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔴 RED: Power, passion, confidence
🔵 BLUE: Trust, elegance, calm royalty
🟣 PURPLE: Luxury, mystery, creativity
🟢 GREEN: Nature, enchantment, renewal
⚫ BLACK: Sophistication, drama, mystery
⚪ WHITE: Purity, ethereal, angelic
🟡 GOLD: Royalty, glamour, celebration

━━━━━ ACCESSORIZING ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• Masks elevate any masquerade look instantly
• Wigs transform your entire silhouette
• Props (swords, wands, staffs) add authenticity
• Shoes matter — match era for full immersion
• Jewelry should match costume metals/colors

━━━━━ PHOTO TIPS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📸 Natural light is your best friend
📸 Strike a character pose, not just a smile
📸 Full-length shots show the complete look
📸 Group photos with matching themes = viral gold

Need personal styling advice? 
Book a free consultation: style@dressup.com
`,
    },
  ],
};

const catalogBData = {
  name: 'DressUp Couture Lookbook',
  fileName: 'DressUp_Couture_Lookbook.zip',
  files: [
    {
      name: 'README.txt',
      content: `╔══════════════════════════════════════════════════════╗
║       DRESSUP — COUTURE LOOKBOOK & BRAND KIT         ║
╚══════════════════════════════════════════════════════╝

Welcome to the exclusive DressUp Couture Lookbook!

This premium package contains our full brand story,
behind-the-scenes look at our design process, and
everything for event planners & wholesale buyers.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📁 WHAT'S INSIDE:
──────────────────
• Couture Lookbook (TXT)      — Full 2025 collection details
• Brand Story (TXT)           — Our journey and mission
• Wholesale Price List (CSV)  — Bulk & partner pricing
• Event Planning Guide (TXT)  — Themed event costume guide
• Fabric & Material Guide     — Premium materials breakdown
• Collaboration Deck (TXT)    — Partnership opportunities
• Testimonials & Press (TXT)  — Press features & reviews

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👑 COUTURE INQUIRIES: couture@dressup.com
🤝 PARTNERSHIPS: partners@dressup.com
📞 VIP LINE: 1-800-555-0200

© 2025 DressUp. Confidential — For authorized use only.
`,
    },
    {
      name: 'Couture_Lookbook_2025.txt',
      content: `╔══════════════════════════════════════════════════════╗
║         DRESSUP COUTURE — LOOKBOOK 2025              ║
╚══════════════════════════════════════════════════════╝

      "Where Imagination Meets Impeccable Craft"

━━━━━ THE 2025 VISION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This year, we draw inspiration from the collision of
classical artistry and modern fantasy. Each piece in
our Couture collection tells a story — your story.

━━━━━ COLLECTION HIGHLIGHTS ━━━━━━━━━━━━━━━━━━━━━━━

✦ MIDNIGHT MASQUERADE SERIES
  Inspired by 18th century Venetian carnival balls.
  Hand-beaded masks, genuine silk gowns, metallic
  thread embroidery. 12 pieces, each limited to
  50 units worldwide.
  Price range: $399 – $899

✦ ENCHANTED FOREST SERIES
  Fairy tale meets haute couture. Living vines in
  3D fabric sculpture, iridescent wing capes, and
  moss-textured corsets. Ideal for themed weddings.
  Price range: $349 – $749

✦ WARRIOR NOBILITY SERIES
  Medieval armor reimagined in luxury materials.
  Laser-cut leather, hand-forged metal accents,
  lined with premium silk. Unisex designs.
  Price range: $449 – $999

✦ CELESTIAL DREAMS SERIES
  Zodiac-inspired collection. Constellation beading,
  holographic fabrics, and light-up LED elements
  sewn into ethereal silhouettes.
  Price range: $299 – $699

✦ GOTHIC ROMANCE SERIES
  Victorian drama meets modern edge. Black velvet,
  crimson satin, antique lace, and hand-painted
  corsets. Dark elegance at its finest.
  Price range: $349 – $799

━━━━━ THE COUTURE EXPERIENCE ━━━━━━━━━━━━━━━━━━━━━

 1. CONSULTATION — Video call with your designer
 2. MEASUREMENT — Precision 15-point body mapping
 3. DESIGN — Custom mockup with fabric swatches
 4. CRAFTING — 2-3 weeks of expert hand-making
 5. FITTING — Virtual or in-person final fitting
 6. DELIVERY — White-glove shipping in keepsake box

Every Couture piece comes with:
  ✅ Certificate of authenticity
  ✅ Preservation garment bag
  ✅ Lifetime alteration guarantee
  ✅ Personal stylist contact
  ✅ Priority access to future collections

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Book your Couture consultation: couture@dressup.com
`,
    },
    {
      name: 'Brand_Story.txt',
      content: `╔══════════════════════════════════════════════════════╗
║           DRESSUP — OUR BRAND STORY                  ║
╚══════════════════════════════════════════════════════╝

━━━━━ THE BEGINNING ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DressUp was born in 2018 from a simple frustration:
why were fancy dress costumes either cheaply made
throwaway items, or prohibitively expensive bespoke
pieces with nothing in between?

Founder Maya Chen, a former fashion designer for
luxury brands, believed everyone deserved to feel
extraordinary — regardless of their budget.

━━━━━ THE MISSION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"To make premium quality fancy dress accessible to
every person, every age, and every imagination."

We believe:
  ★ Costumes are a form of self-expression
  ★ Quality should never be sacrificed for price
  ★ Every body deserves to feel represented
  ★ Sustainability and fashion can coexist
  ★ The joy of dressing up has no age limit

━━━━━ BY THE NUMBERS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  250,000+   Happy customers worldwide
  1,500+     Unique costume designs
  120+       Countries shipped to
  98%        Customer satisfaction rate
  4.9/5      Average product rating
  50+        In-house designers
  15         Awards won

━━━━━ SUSTAINABILITY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  🌱 40% of fabrics from recycled sources
  📦 100% recyclable packaging since 2022
  🌍 Carbon-neutral shipping since 2023
  ♻️ Costume recycling program launched 2024
  🤝 Fair trade certified manufacturers

━━━━━ PRESS & RECOGNITION ━━━━━━━━━━━━━━━━━━━━━━━━

"DressUp has redefined what fancy dress can be."
   — Vogue Magazine

"The Apple of costume design."
   — TechCrunch

"Finally, costumes that adults can be proud to wear."
   — Cosmopolitan

"Our go-to for every themed event."
   — Event Planner Magazine

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Press inquiries: press@dressup.com
`,
    },
    {
      name: 'Wholesale_Price_List.csv',
      content: `Tier,Category,Min Order,Unit Price (USD),RRP (USD),Margin %,Lead Time,MOQ per SKU
Standard,Women Costumes,10 units,$29.99,$49.99-$79.99,40-62%,7-10 days,5
Standard,Men Costumes,10 units,$29.99,$49.99-$79.99,40-62%,7-10 days,5
Standard,Kids Costumes,10 units,$19.99,$34.99-$54.99,43-64%,7-10 days,5
Standard,Accessories,20 units,$9.99,$19.99-$34.99,50-71%,5-7 days,10
Premium,Women Costumes,5 units,$54.99,$89.99-$119.99,39-54%,10-14 days,3
Premium,Men Costumes,5 units,$54.99,$89.99-$129.99,39-58%,10-14 days,3
Premium,Kids Costumes,5 units,$29.99,$44.99-$54.99,33-45%,10-14 days,3
Premium,Couples Sets,5 units,$89.99,$139.99-$179.99,36-50%,10-14 days,3
Premium,Group Sets,3 units,$129.99,$199.99-$349.99,35-63%,14-21 days,2
Couture,Custom Pieces,1 unit,$149.99,$299.99-$999.99,50-85%,14-21 days,1
Couture,Limited Editions,1 unit,$249.99,$399.99-$899.99,37-72%,21-30 days,1

VOLUME DISCOUNTS:
Quantity,Additional Discount
10-24 units,10% off wholesale
25-49 units,15% off wholesale
50-99 units,20% off wholesale
100+ units,25% off wholesale + free shipping

TERMS:
Payment: Net 30 for approved accounts
Returns: 14 days for defective items only
Exclusivity: Territory exclusivity available for 100+ unit commitments
Support: Dedicated wholesale account manager assigned

Contact: wholesale@dressup.com | 1-800-555-0201`,
    },
    {
      name: 'Event_Planning_Guide.txt',
      content: `╔══════════════════════════════════════════════════════╗
║       DRESSUP — EVENT PLANNING COSTUME GUIDE         ║
╚══════════════════════════════════════════════════════╝

The complete guide to costuming your next themed event.

━━━━━ CORPORATE EVENTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏢 THEMED GALAS & AWARD CEREMONIES
   Recommended: Masquerade, Great Gatsby, Hollywood
   Budget: $60-$120 per person
   Lead time: 3-4 weeks
   Group discount: 15-25% for 20+ costumes

🎪 TEAM BUILDING EVENTS
   Recommended: Decades Party, Around the World
   Budget: $40-$80 per person
   Lead time: 2-3 weeks
   Include: Matching accessories for team cohesion

━━━━━ WEDDINGS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💒 THEMED WEDDINGS
   Popular themes:
   • Renaissance Fair — rustic & romantic
   • Fairy Tale — ethereal & magical
   • Medieval — grand & dramatic
   • Masquerade — elegant & mysterious

   Bride & Groom: Couture tier recommended
   Wedding Party: Premium tier
   Guests: Standard tier with theme guidelines

   We provide: Style guide for guests, color
   palette coordination, group fitting sessions

━━━━━ SCHOOLS & YOUTH ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎓 SCHOOL PLAYS & PRODUCTIONS
   Budget-friendly packages from $25/costume
   Bulk rental options available
   Safety-certified materials for all ages
   Quick-change designs for multi-role actors

🎃 SCHOOL EVENTS & DANCES
   Themed collections: Decades, Fairy Tale, Space
   Modesty-appropriate options available
   Parent-approved comfort & safety

━━━━━ PARTIES & CELEBRATIONS ━━━━━━━━━━━━━━━━━━━━━

🎉 BIRTHDAY PARTIES
   Kids: Character packages from $30
   Adults: Theme packages from $50
   Include: Matching party decorations available

🎭 THEATER & PERFORMANCE
   Professional-grade costumes
   Quick-change friendly designs
   Bulk rental program: from $15/costume/week
   Wardrobe management consultation included

━━━━━ EVENT PLANNING CHECKLIST ━━━━━━━━━━━━━━━━━━━

 □ Set theme and color palette
 □ Determine headcount and sizes needed
 □ Contact DressUp for group quote
 □ Order 4-6 weeks before event
 □ Schedule fitting session (virtual or in-person)
 □ Arrange delivery or pickup
 □ Brief attendees on costume care
 □ Plan post-event returns (if rental)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Event specialist: events@dressup.com
Free event consultation: 1-800-555-0199 ext. 3
`,
    },
    {
      name: 'Fabric_Material_Guide.txt',
      content: `╔══════════════════════════════════════════════════════╗
║       DRESSUP — FABRIC & MATERIAL GUIDE              ║
╚══════════════════════════════════════════════════════╝

Understanding our materials helps you choose the
perfect costume for comfort, durability, and style.

━━━━━ STANDARD TIER MATERIALS ━━━━━━━━━━━━━━━━━━━━

🧵 POLYESTER BLEND (Most standard costumes)
   • Durable and wrinkle-resistant
   • Easy machine wash care
   • Excellent color retention
   • Comfortable for all-day wear
   • Weight: Light to medium

🧵 COTTON-POLY BLEND (Select costumes)
   • Breathable and soft
   • Natural feel with easy care
   • Ideal for kids' costumes
   • Hypoallergenic

━━━━━ PREMIUM TIER MATERIALS ━━━━━━━━━━━━━━━━━━━━━

⭐ SATIN
   • Luxurious sheen and drape
   • Smooth, cool to the touch
   • Used in: Gowns, capes, linings
   • Care: Hand wash or dry clean

⭐ VELVET
   • Rich texture and depth
   • Excellent for dramatic pieces
   • Used in: Royalty, Gothic, Victorian
   • Care: Steam, dry clean preferred

⭐ ORGANZA
   • Sheer, lightweight elegance
   • Beautiful layering fabric
   • Used in: Fairy, princess, ethereal looks
   • Care: Hand wash, hang to dry

⭐ STRETCH SPANDEX BLEND
   • 4-way stretch for movement
   • Form-fitting comfort
   • Used in: Superhero, cat suits, bodysuits
   • Care: Machine wash cold

⭐ FAUX LEATHER
   • Authentic look, cruelty-free
   • Durable for action costumes
   • Used in: Warriors, pirates, steampunk
   • Care: Wipe clean, condition yearly

━━━━━ COUTURE TIER MATERIALS ━━━━━━━━━━━━━━━━━━━━━

👑 GENUINE SILK
   • Unmatched luxury feel
   • Natural temperature regulation
   • Hand-dyed custom colors
   • Source: Ethical silk farms

👑 REAL LEATHER ACCENTS
   • Vegetable-tanned, ethically sourced
   • Hand-cut and stitched
   • Develops patina over time
   • Used for belts, bracers, accents

👑 HAND-BEADED EMBELLISHMENTS
   • Glass beads, crystals, pearls
   • Applied by master artisans
   • 40-80 hours per garment
   • Each piece unique

👑 HOLOGRAPHIC & LED FABRICS
   • Light-reactive materials
   • Battery-operated LED elements
   • Rechargeable via USB
   • Up to 8 hours runtime

━━━━━ SAFETY CERTIFICATIONS ━━━━━━━━━━━━━━━━━━━━━

All DressUp materials are:
  ✅ CPSIA compliant (children's products)
  ✅ EN71 certified (European safety)
  ✅ OEKO-TEX Standard 100
  ✅ Flame retardant treated
  ✅ AZO-dye free
  ✅ Non-toxic, hypoallergenic

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Material sourcing inquiries: sourcing@dressup.com
`,
    },
    {
      name: 'Partnership_Opportunities.txt',
      content: `╔══════════════════════════════════════════════════════╗
║       DRESSUP — PARTNERSHIP OPPORTUNITIES            ║
╚══════════════════════════════════════════════════════╝

Join the DressUp family of partners and grow together.

━━━━━ AFFILIATE PROGRAM ━━━━━━━━━━━━━━━━━━━━━━━━━━

  💰 Commission: 12% on all referred sales
  🍪 Cookie duration: 90 days
  📊 Real-time dashboard & analytics
  🎨 Custom creatives & banners provided
  💳 Monthly payouts via PayPal or bank transfer
  📈 Bonus tiers: 15% at $5K/mo, 18% at $10K/mo

  Perfect for: Fashion bloggers, event planners,
  cosplay influencers, parenting bloggers

━━━━━ INFLUENCER COLLABORATIONS ━━━━━━━━━━━━━━━━━━

  📸 Product gifting: 5K+ followers
  💼 Paid collaborations: 25K+ followers
  🤝 Brand ambassador program: 100K+ followers
  🎬 Video content partnerships: YouTube & TikTok

  We provide:
  • Free costumes for content creation
  • Exclusive early access to collections
  • Custom discount codes for audiences
  • Professional photoshoot support
  • Co-created limited edition pieces

━━━━━ WHOLESALE & RETAIL ━━━━━━━━━━━━━━━━━━━━━━━━━

  🏪 Retail partnerships
  • Dedicated account manager
  • Custom display materials (POS)
  • Staff training programs
  • Territory exclusivity options
  • Co-op marketing funds available

  📦 Drop-shipping
  • No inventory required
  • Branded or white-label packaging
  • API integration for your store
  • Real-time inventory sync
  • Same-day dispatch guarantee

━━━━━ EVENT & VENUE PARTNERSHIPS ━━━━━━━━━━━━━━━━━

  🎪 Theme parks & attractions
  🎭 Theaters & performing arts centers
  🎃 Halloween & seasonal attractions
  🏨 Hotels & resorts (themed experiences)
  🎮 Gaming conventions & expos

━━━━━ LICENSING ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Interested in licensing DressUp designs or
  co-branding with your IP? We work with:
  • Entertainment studios
  • Gaming companies
  • Comic book publishers
  • Sports teams
  • Celebrity brands

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Partnership inquiries: partners@dressup.com
Affiliate signup: www.dressup.com/affiliates
`,
    },
    {
      name: 'Press_And_Testimonials.txt',
      content: `╔══════════════════════════════════════════════════════╗
║       DRESSUP — PRESS FEATURES & TESTIMONIALS        ║
╚══════════════════════════════════════════════════════╝

━━━━━ PRESS COVERAGE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VOGUE MAGAZINE — "Best Costume Brands 2025"
"DressUp has single-handedly elevated fancy dress 
from party gimmick to fashion statement. Their 
Couture line rivals many ready-to-wear luxury brands."

TECHCRUNCH — "DressUp Raises $15M Series B"
"The brand that's been called 'the Apple of costume 
design' continues to disrupt with their technology-
first approach to traditional retail."

COSMOPOLITAN — "Top 10 Halloween Picks"
"For the fifth consecutive year, DressUp dominates 
our Halloween best-dressed list. Their Venetian 
Masquerade was the undisputed winner."

EVENT PLANNER MAGAZINE — "Industry Innovator Award"
"DressUp's group ordering system has transformed 
how we approach themed events. The quality-to-price 
ratio is genuinely unmatched in the industry."

PARENTS MAGAZINE — "Safest Kids' Costumes"
"With CPSIA and EN71 certifications across their 
entire kids range, DressUp sets the standard for 
children's costume safety."

━━━━━ CUSTOMER TESTIMONIALS ━━━━━━━━━━━━━━━━━━━━━

⭐⭐⭐⭐⭐ Sarah Mitchell — Halloween Party Host
"The Venetian Masquerade set was absolutely stunning. 
The quality of the fabrics and the attention to detail 
is unmatched. I felt like true royalty at our company 
gala. Everyone wanted to know where I got it!"

⭐⭐⭐⭐⭐ Marcus Johnson — Cosplay Enthusiast
"As someone who does cosplay professionally, I'm very 
picky about costumes. DressUp exceeded all my 
expectations. The Renaissance collection is museum-
quality. These are investment pieces."

⭐⭐⭐⭐⭐ Elena Rodriguez — Event Planner
"I ordered costumes for a corporate themed event — 
40 people, all different sizes. DressUp's team was 
incredible. Every single costume fit perfectly."

⭐⭐⭐⭐⭐ David Chen — Father of Three
"My kids absolutely LOVED their skeleton costumes. 
The glow-in-the-dark details were a huge hit. The 
materials are soft and comfortable."

⭐⭐⭐⭐⭐ Amara Okafor — Theater Director
"We use DressUp costumes for our community theater 
productions. The durability is exceptional — they 
withstand dozens of performances."

⭐⭐⭐⭐⭐ James Whitfield — Wedding Planner
"Themed weddings are all the rage, and DressUp is my 
go-to recommendation. The quality bridges the gap 
between costume and couture."

━━━━━ AWARDS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏆 2025 — Vogue "Best Costume Brand"
🏆 2025 — Event Planner "Industry Innovator"
🏆 2024 — Parents Magazine "Safest Kids Brand"
🏆 2024 — Cosplay Magazine "Best Quality Award"
🏆 2024 — Sustainable Fashion Awards Finalist
🏆 2023 — Forbes "30 Under 30" (Founder)
🏆 2023 — Retail Innovation Award
🏆 2022 — TechCrunch "Startup of the Year"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Press kit & high-res assets: press@dressup.com
`,
    },
  ],
};

/* ─────────────── COMPONENT ─────────────── */

interface CatalogOption {
  id: 'a' | 'b';
  label: string;
  subtitle: string;
  icon: typeof FileArchive;
  accentIcon: typeof Sparkles;
  gradient: string;
  borderGradient: string;
  glowColor: string;
  includes: string[];
  fileCount: number;
  size: string;
  badge: string | null;
  badgeColor: string;
}

const catalogs: CatalogOption[] = [
  {
    id: 'a',
    label: 'Option A — Essentials Catalog',
    subtitle: 'Complete product catalog, size guides, care tips & order form',
    icon: BookOpen,
    accentIcon: Palette,
    gradient: 'from-brand-500 to-pink-500',
    borderGradient: 'from-brand-500/40 via-pink-500/20 to-brand-500/40',
    glowColor: 'brand-500',
    includes: ['500+ Product Catalog (CSV)', 'Comprehensive Size Guide', 'Costume Care Instructions', 'Quick Order Form', 'Complete Style Guide', 'Welcome README'],
    fileCount: 6,
    size: '~28 KB',
    badge: 'Most Downloaded',
    badgeColor: 'bg-brand-500',
  },
  {
    id: 'b',
    label: 'Option B — Couture Lookbook',
    subtitle: 'Premium brand kit with wholesale pricing & partnership info',
    icon: Crown,
    accentIcon: Layers,
    gradient: 'from-accent-500 to-violet-500',
    borderGradient: 'from-accent-500/40 via-violet-500/20 to-accent-500/40',
    glowColor: 'accent-500',
    includes: ['2025 Couture Lookbook', 'Full Brand Story', 'Wholesale Price List (CSV)', 'Event Planning Guide', 'Fabric & Material Guide', 'Partnership Opportunities', 'Press & Testimonials'],
    fileCount: 8,
    size: '~42 KB',
    badge: 'Premium',
    badgeColor: 'bg-accent-500',
  },
];

export default function DownloadCatalogs() {
  const { ref, isVisible } = useScrollReveal();
  const [downloading, setDownloading] = useState<'a' | 'b' | null>(null);
  const [completed, setCompleted] = useState<Set<'a' | 'b'>>(new Set());

  const handleDownload = useCallback(async (option: 'a' | 'b') => {
    if (downloading) return;
    setDownloading(option);

    try {
      const data = option === 'a' ? catalogAData : catalogBData;
      const zip = new JSZip();
      const folder = zip.folder(data.name.replace(/\s+/g, '_'))!;

      for (const file of data.files) {
        folder.file(file.name, file.content);
      }

      const blob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 },
      });

      saveAs(blob, data.fileName);

      setCompleted((prev) => new Set(prev).add(option));
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setTimeout(() => setDownloading(null), 600);
    }
  }, [downloading]);

  return (
    <section ref={ref} id="downloads" className="py-24 lg:py-32 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-surface-elevated/40 to-surface" />
      <div className="absolute top-1/3 -left-32 w-[500px] h-[500px] bg-brand-500/5 rounded-full blur-[180px]" />
      <div className="absolute bottom-1/3 -right-32 w-[500px] h-[500px] bg-accent-500/5 rounded-full blur-[180px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light text-sm font-medium text-accent-300 mb-6"
          >
            <Download className="w-4 h-4" />
            Free Downloads
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Download Our{' '}
            <span className="gradient-text">Catalogs</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400 leading-relaxed"
          >
            Get everything you need in one click. Choose the catalog that fits your needs — 
            each packed with detailed product info, guides, and exclusive resources.
          </motion.p>
        </div>

        {/* Two catalog cards */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8 max-w-5xl mx-auto">
          {catalogs.map((catalog, i) => {
            const isDownloading = downloading === catalog.id;
            const isCompleted = completed.has(catalog.id);

            return (
              <motion.div
                key={catalog.id}
                initial={{ opacity: 0, y: 30 }}
                animate={isVisible ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: i * 0.15 + 0.25 }}
                className="group relative"
              >
                {/* Glow border on hover */}
                <div className={`absolute -inset-[1px] rounded-3xl bg-gradient-to-br ${catalog.borderGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm`} />
                <div className={`absolute -inset-[1px] rounded-3xl bg-gradient-to-br ${catalog.borderGradient} opacity-0 group-hover:opacity-60 transition-opacity duration-500`} />

                <div className="relative glass rounded-3xl overflow-hidden h-full flex flex-col">
                  {/* Top accent bar */}
                  <div className={`h-1 bg-gradient-to-r ${catalog.gradient}`} />

                  <div className="p-7 lg:p-8 flex flex-col flex-1">
                    {/* Badge + Icon row */}
                    <div className="flex items-start justify-between mb-6">
                      <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${catalog.gradient} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <catalog.icon className="w-7 h-7 text-white" />
                      </div>
                      {catalog.badge && (
                        <span className={`${catalog.badgeColor} text-white text-xs font-bold px-3 py-1.5 rounded-full`}>
                          {catalog.badge}
                        </span>
                      )}
                    </div>

                    {/* Title */}
                    <h3 className="text-xl font-bold text-white mb-2">{catalog.label}</h3>
                    <p className="text-sm text-gray-400 mb-6 leading-relaxed">{catalog.subtitle}</p>

                    {/* Meta row */}
                    <div className="flex items-center gap-4 mb-6 text-xs text-gray-500">
                      <div className="flex items-center gap-1.5">
                        <FileArchive className="w-3.5 h-3.5" />
                        <span>{catalog.fileCount} files</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" />
                        <span>{catalog.size}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Star className="w-3.5 h-3.5 fill-gold-400 text-gold-400" />
                        <span className="text-gray-400">Free</span>
                      </div>
                    </div>

                    {/* What's included */}
                    <div className="flex-1 mb-8">
                      <p className="text-xs font-semibold uppercase tracking-widest text-gray-500 mb-3">What's included</p>
                      <div className="space-y-2.5">
                        {catalog.includes.map((item, j) => (
                          <motion.div
                            key={j}
                            initial={{ opacity: 0, x: -10 }}
                            animate={isVisible ? { opacity: 1, x: 0 } : {}}
                            transition={{ duration: 0.3, delay: j * 0.04 + i * 0.15 + 0.4 }}
                            className="flex items-center gap-2.5"
                          >
                            <div className={`w-4.5 h-4.5 rounded-full bg-gradient-to-br ${catalog.gradient} flex items-center justify-center flex-shrink-0`} style={{ width: '18px', height: '18px' }}>
                              <Check className="w-2.5 h-2.5 text-white" />
                            </div>
                            <span className="text-sm text-gray-300">{item}</span>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Download button */}
                    <button
                      onClick={() => handleDownload(catalog.id)}
                      disabled={isDownloading}
                      className={`
                        w-full py-4 rounded-2xl font-semibold text-base transition-all duration-300 relative overflow-hidden
                        flex items-center justify-center gap-2.5
                        ${isCompleted
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : `btn-primary text-white relative z-10`
                        }
                        ${isDownloading ? 'cursor-wait' : 'cursor-pointer'}
                      `}
                      aria-label={`Download ${catalog.label}`}
                    >
                      <AnimatePresence mode="wait">
                        {isDownloading ? (
                          <motion.span
                            key="loading"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            className="relative z-10 flex items-center gap-2"
                          >
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Generating ZIP...
                          </motion.span>
                        ) : isCompleted ? (
                          <motion.span
                            key="done"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            className="flex items-center gap-2"
                          >
                            <CheckCircle className="w-5 h-5" />
                            Downloaded — Click to Re-download
                          </motion.span>
                        ) : (
                          <motion.span
                            key="default"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            className="relative z-10 flex items-center gap-2"
                          >
                            <Download className="w-5 h-5" />
                            Download ZIP File
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-12 text-center"
        >
          <div className="glass-light inline-flex items-center gap-3 px-6 py-3.5 rounded-2xl">
            <div className="flex items-center gap-1">
              <Shirt className="w-4 h-4 text-brand-400" />
              <Image className="w-4 h-4 text-accent-400" />
              <Users className="w-4 h-4 text-pink-400" />
            </div>
            <span className="text-sm text-gray-400">
              Both catalogs are <span className="text-white font-semibold">100% free</span> — no email required. 
              Instant download, no strings attached.
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
