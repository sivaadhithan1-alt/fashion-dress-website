import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { ArrowUpRight } from 'lucide-react';

const categories = [
  {
    title: 'Women',
    subtitle: '420+ Styles',
    image: 'https://images.pexels.com/photos/9391698/pexels-photo-9391698.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400',
    color: 'from-pink-500/80 to-rose-700/80',
  },
  {
    title: 'Men',
    subtitle: '350+ Styles',
    image: 'https://images.pexels.com/photos/29155437/pexels-photo-29155437.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400',
    color: 'from-violet-500/80 to-indigo-700/80',
  },
  {
    title: 'Kids',
    subtitle: '280+ Styles',
    image: 'https://images.pexels.com/photos/9740423/pexels-photo-9740423.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400',
    color: 'from-amber-500/80 to-orange-700/80',
  },
  {
    title: 'Groups & Couples',
    subtitle: '150+ Themes',
    image: 'https://images.pexels.com/photos/31089869/pexels-photo-31089869.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400',
    color: 'from-emerald-500/80 to-teal-700/80',
  },
  {
    title: 'Party & Celebration',
    subtitle: '200+ Options',
    image: 'https://images.pexels.com/photos/33038887/pexels-photo-33038887.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400',
    color: 'from-cyan-500/80 to-blue-700/80',
  },
];

export default function Categories() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} id="categories" className="py-24 lg:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            Shop By Category
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Something for{' '}
            <span className="gradient-text">Everyone</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400"
          >
            From tiny tots to grown-up heroes — every person deserves to feel magical. Browse by who you're shopping for.
          </motion.p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-5">
          {categories.map((cat, i) => (
            <motion.a
              key={cat.title}
              href="#collections"
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 + 0.2 }}
              className={`group relative rounded-2xl overflow-hidden cursor-pointer card-hover ${
                i === 0 ? 'col-span-2 lg:col-span-2 row-span-2' : 'aspect-[3/4]'
              }`}
              style={{ minHeight: i === 0 ? '420px' : undefined }}
            >
              <img
                src={cat.image}
                alt={cat.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />
              <div className={`absolute inset-0 bg-gradient-to-t ${cat.color} opacity-60 group-hover:opacity-70 transition-opacity duration-300`} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              
              <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                <div className="flex items-end justify-between">
                  <div>
                    <h3 className="text-lg lg:text-xl font-bold text-white mb-1">{cat.title}</h3>
                    <p className="text-sm text-white/70">{cat.subtitle}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/20 group-hover:scale-110 transition-all duration-300">
                    <ArrowUpRight className="w-5 h-5 text-white group-hover:rotate-45 transition-transform duration-300" />
                  </div>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
