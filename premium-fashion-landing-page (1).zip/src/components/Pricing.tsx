import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Check, Sparkles, Zap, Crown } from 'lucide-react';

const plans = [
  {
    name: 'Standard',
    icon: Zap,
    description: 'Great quality costumes for casual events',
    price: 49,
    period: 'from',
    features: [
      'Access to 500+ standard designs',
      'Standard fabric & materials',
      'Sizes XS – 3XL',
      'Free standard shipping',
      '14-day returns',
      'Email support',
    ],
    cta: 'Browse Standard',
    popular: false,
    gradient: 'from-gray-600 to-gray-700',
    iconGradient: 'from-gray-400 to-gray-500',
  },
  {
    name: 'Premium',
    icon: Sparkles,
    description: 'Our most popular — superior quality & fit',
    price: 89,
    period: 'from',
    features: [
      'Access to 1,200+ premium designs',
      'Premium fabrics & hand-stitched details',
      'Sizes XXS – 5XL',
      'Free express shipping',
      '30-day free returns',
      'Priority 24/7 support',
      'Matching accessories included',
      'Exclusive seasonal drops',
    ],
    cta: 'Browse Premium',
    popular: true,
    gradient: 'from-brand-500 to-accent-500',
    iconGradient: 'from-brand-400 to-accent-400',
  },
  {
    name: 'Couture',
    icon: Crown,
    description: 'Bespoke costumes tailored to your vision',
    price: 199,
    period: 'from',
    features: [
      'All Premium features included',
      'Custom measurement & tailoring',
      'Luxury designer fabrics',
      'Unlimited design consultations',
      'Same-day priority shipping',
      'VIP concierge support',
      'Exclusive limited editions',
      'Personal stylist assigned',
    ],
    cta: 'Browse Couture',
    popular: false,
    gradient: 'from-amber-500 to-amber-600',
    iconGradient: 'from-gold-400 to-gold-500',
  },
];

export default function Pricing() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} id="pricing" className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-surface-elevated/30 to-surface" />
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-brand-500/5 rounded-full blur-[150px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
          >
            Pricing Tiers
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance"
          >
            Choose Your{' '}
            <span className="gradient-text">Experience</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-5 text-lg text-gray-400"
          >
            Three tiers of extraordinary. Pick the level that matches your vision.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 items-start">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.15 + 0.2 }}
              className={`relative rounded-3xl overflow-hidden card-hover ${
                plan.popular
                  ? 'glass border-brand-500/30 md:-mt-4 md:mb-0'
                  : 'glass-light'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-brand-500 to-accent-500" />
              )}

              <div className="p-7 lg:p-8">
                {plan.popular && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 text-brand-400 text-xs font-semibold mb-4">
                    <Sparkles className="w-3 h-3" />
                    Most Popular
                  </span>
                )}

                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.iconGradient} flex items-center justify-center mb-5`}>
                  <plan.icon className="w-6 h-6 text-white" />
                </div>

                <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                <p className="text-sm text-gray-400 mb-6">{plan.description}</p>

                <div className="flex items-baseline gap-1 mb-8">
                  <span className="text-xs text-gray-500 uppercase">{plan.period}</span>
                  <span className="text-4xl lg:text-5xl font-extrabold text-white">${plan.price}</span>
                </div>

                <a
                  href="#"
                  className={`block w-full py-3.5 rounded-xl text-center font-semibold transition-all duration-300 ${
                    plan.popular
                      ? 'btn-primary text-white relative z-10'
                      : 'btn-secondary text-white'
                  }`}
                >
                  <span className="relative z-10">{plan.cta}</span>
                </a>

                <div className="mt-8 space-y-3">
                  {plan.features.map((feature, j) => (
                    <div key={j} className="flex items-start gap-3">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        plan.popular ? 'bg-brand-500/20' : 'bg-white/5'
                      }`}>
                        <Check className={`w-3 h-3 ${plan.popular ? 'text-brand-400' : 'text-gray-400'}`} />
                      </div>
                      <span className="text-sm text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="text-center text-sm text-gray-500 mt-10"
        >
          🎉 Use code <span className="text-brand-400 font-semibold">FIRST20</span> for 20% off your first order. Free shipping on all orders over $75.
        </motion.p>
      </div>
    </section>
  );
}
