import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Check, Sparkles, Crown, Globe, Scissors, Recycle } from 'lucide-react';

const benefits = [
  { icon: Crown, text: 'Premium materials sourced ethically worldwide' },
  { icon: Scissors, text: 'Custom tailoring available for the perfect fit' },
  { icon: Globe, text: 'Free worldwide shipping on orders over $75' },
  { icon: Recycle, text: 'Sustainable packaging and eco-friendly options' },
  { icon: Sparkles, text: 'Exclusive designs you won\'t find anywhere else' },
  { icon: Check, text: 'Easy 30-day returns with free shipping' },
];

export default function Benefits() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} id="benefits" className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-surface-elevated/50 to-surface" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-500/3 rounded-full blur-[200px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image grid */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                  <img
                    src="https://images.pexels.com/photos/9393377/pexels-photo-9393377.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=350"
                    alt="Woman choosing costumes"
                    className="w-full h-56 object-cover hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
                <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                  <img
                    src="https://images.pexels.com/photos/6184938/pexels-photo-6184938.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=350"
                    alt="Young adults celebrating"
                    className="w-full h-44 object-cover hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                  <img
                    src="https://images.pexels.com/photos/9391695/pexels-photo-9391695.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=350"
                    alt="Blue hair masquerade"
                    className="w-full h-44 object-cover hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
                <div className="rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                  <img
                    src="https://images.pexels.com/photos/9740508/pexels-photo-9740508.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=350"
                    alt="Kid in costume"
                    className="w-full h-56 object-cover hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
              </div>
            </div>

            {/* Floating stat card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isVisible ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="absolute -bottom-6 left-1/2 -translate-x-1/2 glass rounded-2xl px-6 py-4 shadow-xl flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-500 to-accent-500 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">98%</p>
                <p className="text-xs text-gray-400">Customer Satisfaction</p>
              </div>
            </motion.div>
          </motion.div>

          {/* Right - Content */}
          <div>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-sm font-semibold uppercase tracking-widest text-brand-400 mb-4"
            >
              The DressUp Difference
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance mb-6"
            >
              More Than Just a{' '}
              <span className="gradient-text">Costume</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-lg text-gray-400 mb-10 leading-relaxed"
            >
              We craft experiences that transform how you see yourself. Every stitch, every detail, 
              every moment is designed to make you feel like the character you've always dreamed of being.
            </motion.p>

            <div className="space-y-4">
              {benefits.map((benefit, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isVisible ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.4, delay: i * 0.08 + 0.35 }}
                  className="flex items-center gap-4 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-brand-500/20 transition-colors">
                    <benefit.icon className="w-5 h-5 text-brand-400" />
                  </div>
                  <span className="text-gray-300 group-hover:text-white transition-colors">{benefit.text}</span>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="mt-10"
            >
              <a
                href="#pricing"
                className="btn-primary inline-flex items-center gap-2 px-8 py-4 rounded-2xl text-white font-semibold relative z-10"
              >
                <span className="relative z-10">Start Shopping</span>
              </a>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
